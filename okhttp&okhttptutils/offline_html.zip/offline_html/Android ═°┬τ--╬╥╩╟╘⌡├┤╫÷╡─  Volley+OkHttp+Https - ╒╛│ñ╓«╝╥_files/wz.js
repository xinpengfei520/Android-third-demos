﻿document.write ('<ul class="sideAdList bgf fr">');
document.write ('<li><i></i><a href="http://www.ihuyi.com/duanxinjiekou/" class="f_red" target="_blank"><font color="red"><strong>秒到短信接口 免费试用</strong></font></a></li>');
document.write ('<li><i></i><a href="http://www.it202.com/server/" class="f_blue" target="_blank"><strong>美国/香港/高防服务器</strong></a></li>');
document.write ('<li><i></i><a href="http://ad.41.cn/yinlutong/?chzwwwwd" class="f_blue" target="_blank"><strong>三方支付接口0.3秒结算</strong></a></li>');
document.write ('<li><i></i><a href="http://www.yunfangyu.com/fangan/jdfhq.html" target="_blank"><font color="red"><b>无限防御各类CC攻击</b></font></a></li>');
document.write ('<li><i></i><a href="http://www.west.cn/" target="_blank"><font color="red">西部数码主机全国3强</font></a></li>');
document.write ('<li><i></i><a href="http://www.danet.net.cn/dedicated_Server.aspx" class="f_blue" target="_blank"><b>台湾 高防服务器免备案</b></a></li>');
document.write ('</ul>');