var digg = {
    done : [],
	data : null,
	get  : function(contentid, obj){
			var t = this;
			$.getJSON('http://app.chinaz.com/?app=digg&contentid='+contentid+'&type='+obj+'&jsoncallback=?', function(data){
			digg.data = data;		
			if(!obj){
				t.render(data.supports, 'supports');
				t.render(data.againsts, 'againsts');
			}else{	
				t.render(data.supports, obj);
			}
			if(data.done) {
				t.done[contentid] = true;
			}
		})
	},
	set: function(contentid, obj){
		var t = this;
		// if(t.done[contentid]) {
			// if(obj == 'supports'){
				// alert('您已经顶过了');
			// }else{
				// alert('您已经踩过了');
			// }
			// return;
		// }
		$.getJSON('http://app.chinaz.com/?app=digg&contentid='+contentid+'&type='+obj+'&jsoncallback=?&flag=1', function(data){
			if(data > 0) {
				t.done[contentid] = true;
				var diggtime;
				t.render(data, obj);
			} else {
				if(obj == 'supports'){
					alert('您已经顶过了');
				}else{
					alert('您已经踩过了');
				}
				return;
			}
		});
	},
	render: function(v, obj){
			var t = this;
			s = parseInt(v);
			$('#'+obj).html(s);
	}
}