package com.harvic.other;

public class ThirdEvent {

	private String mMsg;
	public ThirdEvent(String msg) {
		// TODO Auto-generated constructor stub
		mMsg = msg;
	}
	public String getMsg(){
		return mMsg;
	}
}
