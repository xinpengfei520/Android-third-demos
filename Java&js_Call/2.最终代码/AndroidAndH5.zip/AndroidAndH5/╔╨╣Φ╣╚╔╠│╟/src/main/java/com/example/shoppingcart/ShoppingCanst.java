package com.example.shoppingcart;

import java.util.List;

public class ShoppingCanst {
	public static List<ShopBean> shopBeanlist;			//购物车数据集合
	public static List<AddressBean> addressList;//收件人信息集合
}
