package org.xutils.common.task;

/**
 * Created by wyouflf on 15/6/5.
 * 任务的优先级
 */
public enum Priority {
    UI_TOP, UI_NORMAL, UI_LOW, DEFAULT, BG_TOP, BG_NORMAL, BG_LOW;
}
