/*
$(function()
{
	function advertising()
	{
		var pageHtml = '<div id=\"c1\"><p><img src=\"http://img.chinaz.com/ad/img/close.gif\" onclick="document.getElementById(\'c1\').remove();document.getElementById(\'c2\').remove();\"/></p><a href=\"http://click.aliyun.com/m/247/\" target=\"_blank\"><img src=\"http://img.chinaz.com/ad/img/2014ad2.jpg\" border=\"0\" width=\"120\" /></a></div><div id=\"c2\"><p><img src=\"http://img.chinaz.com/ad/img/close.gif\" onclick="document.getElementById(\'c1\').remove();document.getElementById(\'c2\').remove();\" style=\"cursor:pointer;margin-left:21px;\" /></p><a href="http://click.aliyun.com/m/247/\" target=\"_blank\"><img src=\"http://img.chinaz.com/ad/img/2014ad2.jpg\" border=\"0\" width=\"120\" /></a></div>';
		var divPage = $('body').hasClass('bodyAdvertising');
		if(divPage == false)
		{
			$('body').addClass('bodyAdvertising').append(pageHtml)
		}
		var vwidth = document.body.clientWidth;
		var advWidth = 120;
		var l = (document.body.clientWidth-1000)/2-advWidth;
		$('#c1,#c2').css({'z-index':10,'position':'fixed','width':advWidth,'top':'50%','margin-top':-100,'_display':'none'});
		if(vwidth > 1000+advWidth*2)
		{
			$('#c1,#c2').show();
			$('#c1').css({'left':l/2});
			$('#c2').css({'right':l/2});	
		}
		else
		{
			$('#c1,#c2').hide();	
		}
	}
	advertising();
	window.onresize = function()
	{
		advertising();
	}
});
*/